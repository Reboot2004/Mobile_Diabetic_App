import 'package:flutter/material.dart';
import 'MLModel.dart';
import 'login.dart'; // Import the necessary Dart file for MLModel
//import 'ThermographyDL.dart'; // Import the necessary Dart file for ThermographyDL
//import 'RetinopathyDL.dart'; // Import the necessary Dart file for RetinopathyDL

class WelcomeScreen extends StatelessWidget {
  final String username;

  const WelcomeScreen({Key? key, required this.username}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, $username'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('Menu'),
            ),
            _buildDrawerItem(context, 'ML Model', HomePage()),
            _buildDrawerItem(context, 'Thermography DL', null), // Add the appropriate widget
            _buildDrawerItem(context, 'Retinopathy DL', null), // Add the appropriate widget
            SizedBox(height: 20),
            _buildLogoutButton(context),
          ],
        ),
      ),
      body: Center(
        child: Text(
          'Welcome to the App, $username!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }

  Widget _buildDrawerItem(BuildContext context, String title, Widget? page) {
    return InkWell(
      onTap: () {
        Navigator.pop(context); // Close the drawer
        if (page != null) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          );
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        color: page != null ? Colors.transparent : Colors.grey.shade300,
        child: Text(
          title,
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pop(context); // Close the drawer
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Login()),
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        color: Colors.red, // Change the color for the Logout button
        child: Text(
          'Logout',
          style: TextStyle(fontSize: 16, color: Colors.white),
        ),
      ),
    );
  }
}

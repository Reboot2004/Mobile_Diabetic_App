import 'package:email_otp/email_otp.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:twilio_flutter/twilio_flutter.dart';
import 'main.dart';
import 'login.dart';
import 'email.dart';
class Register extends StatefulWidget {
  const Register({super.key});
  @override
  State<Register> createState() => _RegisterState();
}
class _RegisterState extends State<Register> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final CollectionReference usersCollection = FirebaseFirestore.instance.collection('users');

  TextEditingController usernameC = TextEditingController();
  TextEditingController emailC = TextEditingController();
  TextEditingController passwordC = TextEditingController();
  TextEditingController confirmPasswordC = TextEditingController();
  TextEditingController otpC = TextEditingController();
  TextEditingController phoneNumberC = TextEditingController();
  EmailVerification _emailVerification = EmailVerification(email1 : '', password1: '', username1: '', phone1 : '');
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(
          title: const Text('Mobile Diabetic App'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                  children:[
                    const Padding(
                      padding: EdgeInsets.fromLTRB(0,40,0,60),
                      child: Text('Sign Up',style:TextStyle(fontSize: 37.5,fontWeight: FontWeight.bold)),
                    ),
                    const Text('Username',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: usernameC, decoration: const InputDecoration(labelText: 'Username',), validator: (value) {
                        if (value!.isEmpty) {
                          return 'Username is required';
                        }
                        return null;
                      },
                      ),
                    ),
                    const Text('Phone Number',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: phoneNumberC, decoration: const InputDecoration(labelText: 'Phone Number',), validator: (value) {
                        if (value!.isEmpty) {
                          return 'Phone Number is required';
                        }
                        return null;
                      },
                      ),
                    ),
                    const Text('E-mail',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: emailC, decoration: const InputDecoration(labelText: 'Email',),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Email is required';
                          }
                          if (!value.contains('@')) {
                            return 'Enter a valid email address';
                          }
                          return null;
                        },
                      ),
                    ),
                    const Text('Password',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: passwordC, decoration: const InputDecoration(labelText: 'Password',), obscureText: true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Password is required';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters';
                          }
                          return null;
                        },
                      ),
                    ),
                    const Text('Confirm Password',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: confirmPasswordC, decoration: const InputDecoration(labelText: 'Confirm Password',), obscureText: true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please confirm your password';
                          }
                          if (value != passwordC.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                    ),
                    TextButton(style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => PhoneVerification(phoneNumberC: phoneNumberC,emailC: emailC,usernameC: usernameC,passwordC: passwordC),)
                      );
                    },child: const Text('Verify via Phone OTP'),),
                    TextButton(
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                        foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      ),
                      onPressed: () async {
                        await _emailVerification.sendEmailOTP(emailC.text);
                      },
                      child: const Text('Send Email OTP'),
                    ),
                    OtpInput(
                      otpController: otpC,
                      onVerifyPressed: () async {
                        await _emailVerification.verifyEmailOTP(context, otpC.text, emailC.text, usernameC.text, passwordC.text, phoneNumberC.text);
                        String email = emailC.text;
                        String username = usernameC.text;
                        String password = passwordC.text;
                        String phone = phoneNumberC.text;
                        print(email);
                        print(username);
                        print(password);
                        EmailVerification(email1: email,
                          username1: username,
                          password1: password,
                          phone1: phone);
                      },
                    ),

                    // TextButton(
                    //   style: ButtonStyle(
                    //     backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                    //     foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    //   ),
                    //   onPressed: () async {
                    //     Navigator.push(
                    //         context,
                    //         MaterialPageRoute(builder: (context) => OtpInputPage(),)
                    //     );
                    //     // Verify email OTP
                    //     bool isEmailVerified = await _emailVerification.verifyEmailOTP(context,otpC.text,emailC.text, usernameC.text, passwordC.text);
                    //     // Assuming you have these values from your registration form
                    //
                    //     if (isEmailVerified) {
                    //       ScaffoldMessenger.of(context).showSnackBar(
                    //         SnackBar(
                    //           content: Text('Email OTP verified successfully'),
                    //         ),
                    //       );
                    //     } else {
                    //       ScaffoldMessenger.of(context).showSnackBar(
                    //         SnackBar(
                    //           content: Text('Email OTP verification failed'),
                    //         ),
                    //       );
                    //     }
                    //   },
                    //   child: const Text('Verify Email OTP'),
                    // ),
          ]
              ),
            )
        )

    );

  }
  Future<void> registerUser(String email, String password, String username, String phone) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await usersCollection.add({
        'username': username,
        'email': email,
        'uid': userCredential.user?.uid,
        'password' : password,
        'phone' : phone,
      });
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Registration Successful'),
            content: const Text('You can now sign in with your credentials.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
                  // Navigate to the login page or any other screen.
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      print("Error during registration: $e");
      // Handle the registration error, e.g., display an error message.
    }
  }
}
class TwilioService {
  final String accountSid = 'AC01c9b0402b8303c530a9527b5f0e40b7';
  final String authToken = '1c1e2e8e0248fec0f0a0ea7e334ddef1';
  final String serviceSid = 'VA7a847bec1b62a39568f8c90995db139a';
  Future<VerificationResult?> initiateVerification(String phoneNumber) async {
    try {
      final response = await http.post(
        Uri.parse(
            'https://verify.twilio.com/v2/Services/$serviceSid/Verifications'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ${base64Encode(
              utf8.encode('$accountSid:$authToken'))}',
        },
        body: {
          'To': phoneNumber,
          'Channel': 'sms',
        },
      );
      if (response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        final String verificationSid = responseData['sid'];
        return VerificationResult(
          verificationSid: verificationSid,
          statusCode: response.statusCode,
        );
      } else {
        print('Error initiating verification: ${response.body}');
        return null;
      }
    } catch (e) {
      print('Error initiating verification: $e');
      return null;
    }
  }
  Future<bool> checkVerificationCode(String phoneNumber,String verificationSid,String code) async {
    try {
      if (verificationSid != null) {
        final response = await http.post(
          Uri.parse(
              'https://verify.twilio.com/v2/Services/$serviceSid/Verifications/$verificationSid'),
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ${base64Encode(
                utf8.encode('$accountSid:$authToken'))}',
          },
          body: {
            'To': phoneNumber,
            'Code': code,
          },
        );
        print(response.body);

        return response.statusCode == 200 &&
            json.decode(response.body)['status'] == 'approved';
      }else{
        print('error: verificationSid not found');
        return false;
      }
    } catch (e) {
      print('Error checking verification code: $e');
      return false;
    }
  }
}
class PhoneVerification extends StatefulWidget {
  final TextEditingController phoneNumberC;
  final TextEditingController emailC;
  final TextEditingController usernameC;
  final TextEditingController passwordC;

  const PhoneVerification({super.key, required this.phoneNumberC, required this.emailC, required this.usernameC, required this.passwordC});

  @override
  State<PhoneVerification> createState() => _PhoneVerificationState(phoneNumberC: phoneNumberC,emailC: emailC,usernameC: usernameC,passwordC: passwordC);
}

class _PhoneVerificationState extends State<PhoneVerification> {
  final TextEditingController phoneNumberC;
  final TextEditingController emailC;
  final TextEditingController usernameC;
  final TextEditingController passwordC;
  TextEditingController otpC = TextEditingController();
  var register = _RegisterState();
  var twilioService = TwilioService();
  TwilioFlutter? twilioFlutter;
  String? verificationSid;
  // void _navigateToOtpInputPage() {
  //   Navigator.push(
  //     context,
  //     MaterialPageRoute(builder: (context) => OtpInputPage()),
  //   );
  // }

  _PhoneVerificationState({required this.phoneNumberC, required this.emailC, required this.usernameC, required this.passwordC});

  @override
  void initState(){
    super.initState();
    twilioFlutter = TwilioFlutter(
      accountSid: 'AC01c9b0402b8303c530a9527b5f0e40b7',
      authToken: '1c1e2e8e0248fec0f0a0ea7e334ddef1',
      twilioNumber: '+18447953968',
    );
  }

  @override
  void dispose() {
    twilioFlutter=null;
    super.dispose();
  }

  void sendOTP() async {
    String phoneNumber = phoneNumberC.text;
    VerificationResult? verificationResult = await twilioService.initiateVerification('+91'+phoneNumber);

    if(verificationResult != null) {
      verificationSid = verificationResult.verificationSid;
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('OTP Sent'),
            content: const Text('An OTP has been sent to your phone number.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  //_navigateToOtpInputPage(); // Navigate to OTP input page
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Handle error when OTP cannot be sent
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text('Failed to send OTP. Please try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }


  void verifyOTP() async {
    String phoneNumber = phoneNumberC.text;
    String userEnteredOTP = otpC.text;
    var twilioService = TwilioService();


    if (verificationSid != null) {
      bool isVerified = await twilioService.checkVerificationCode( '+91' + phoneNumberC.text ,verificationSid!, userEnteredOTP);
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('OTP Verified'),
            content: const Text('Your OTP has been successfully verified.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('OTP Verification Failed'),
            content: const Text('Invalid OTP. Please try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile Diabetic App'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(0, 40, 0, 60),
              child: Text('Phone Verification', style: TextStyle(fontSize: 37.5, fontWeight: FontWeight.bold)),
            ),
            const Text('Phone Number', style: TextStyle(fontSize: 18)),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: SizedBox(
                    width: 200,
                    child: TextField(controller: phoneNumberC, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Enter your phone number'),),
                  ),
                ),
                TextButton(
                  onPressed: () => sendOTP(),
                  style: ButtonStyle(
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  ),
                  child: const Text('Send OTP'),
                ),
              ],
            ),
            const Text('OTP', style: TextStyle(fontSize: 18)),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: SizedBox(
                    width: 200,
                    child: TextField(controller: otpC, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Enter OTP'),),
                  ),
                ),
                TextButton(
                  onPressed: () => verifyOTP(),
                  style: ButtonStyle(
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),),
                  child: const Text('Verify OTP'),
                ),
              ],
            ),
            TextButton(
              onPressed: () {
                register.registerUser(emailC.text,passwordC.text,usernameC.text,phoneNumberC.text);
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    if(verificationSid != null) {
                      return AlertDialog(
                        title: Text('Registration Successful'),
                        content: Text(
                            'You can now sign in with your credentials.'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Login()),
                              );
                              // Navigate to the login page or any other screen.
                            },
                            child: Text('OK'),
                          ),
                        ],
                      );
                    }else{
                      return AlertDialog(
                        title: Text('Registration Failed'),
                        content: Text(
                            'You need to verify first.'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                              // Navigate to the login page or any other screen.
                            },
                            child: Text('OK'),
                          ),
                        ],
                      );
                    }
                  },
                );
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),
              child: const Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}
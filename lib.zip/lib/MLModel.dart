// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
// import 'package:multiselect_formfield/multiselect_formfield.dart';
// import 'package:python_ffi/python_ffi.dart';
// import 'package:flython/flython.dart';
// import 'package:dartpy/dartpy.dart';
// //import 'py.dart';
// class MLModel extends StatefulWidget {
//   @override
//   _MLModelState createState() => _MLModelState();
// }
//
// class _MLModelState extends State<MLModel> {
//   List<String> mlModels = ['rfc','2','3','4','5','6','7','8','9','10'];
//   String selectedData = '';
//   String selectedModel = '';
//   String predictionResult = '';
//
//   TextEditingController pregnanciesController = TextEditingController();
//   TextEditingController glucoseController = TextEditingController();
//   TextEditingController bloodPressureController = TextEditingController();
//   TextEditingController skinThicknessController = TextEditingController();
//   TextEditingController insulinController = TextEditingController();
//   TextEditingController bmiController = TextEditingController();
//   TextEditingController ageController = TextEditingController();
//
//   List<Map<String, dynamic>> data = [
//     {'DataPoint': 1, 'Pregnancies': 6, 'Glucose': 148, 'BloodPressure': 72, 'SkinThickness': 35, 'Insulin': 0, 'BMI': 33.6, 'DiabetesPedigreeFunction': 0.627, 'Age': 50, 'Outcome': 1},
//     {'DataPoint': 2, 'Pregnancies': 1, 'Glucose': 85, 'BloodPressure': 66, 'SkinThickness': 29, 'Insulin': 0, 'BMI': 26.6, 'DiabetesPedigreeFunction': 0.351, 'Age': 31, 'Outcome': 0},
//     {'DataPoint': 3, 'Pregnancies': 8, 'Glucose': 183, 'BloodPressure': 64, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 23.3, 'DiabetesPedigreeFunction': 0.672, 'Age': 32, 'Outcome': 1},
//     {'DataPoint': 4, 'Pregnancies': 1, 'Glucose': 89, 'BloodPressure': 66, 'SkinThickness': 23, 'Insulin': 94, 'BMI': 28.1, 'DiabetesPedigreeFunction': 0.167, 'Age': 21, 'Outcome': 0},
//     {'DataPoint': 5, 'Pregnancies': 0, 'Glucose': 137, 'BloodPressure': 40, 'SkinThickness': 35, 'Insulin': 168, 'BMI': 43.1, 'DiabetesPedigreeFunction': 2.288, 'Age': 33, 'Outcome': 1},
//     {'DataPoint': 6, 'Pregnancies': 5, 'Glucose': 116, 'BloodPressure': 74, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 25.6, 'DiabetesPedigreeFunction': 0.201, 'Age': 30, 'Outcome': 0},
//     {'DataPoint': 7, 'Pregnancies': 3, 'Glucose': 78, 'BloodPressure': 50, 'SkinThickness': 32, 'Insulin': 88, 'BMI': 31, 'DiabetesPedigreeFunction': 0.248, 'Age': 26, 'Outcome': 1},
//     {'DataPoint': 8, 'Pregnancies': 10, 'Glucose': 115, 'BloodPressure': 0, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 35.3, 'DiabetesPedigreeFunction': 0.134, 'Age': 29, 'Outcome': 0},
//     {'DataPoint': 9, 'Pregnancies': 2, 'Glucose': 197, 'BloodPressure': 70, 'SkinThickness': 45, 'Insulin': 543, 'BMI': 30.5, 'DiabetesPedigreeFunction': 0.158, 'Age': 53, 'Outcome': 1},
//     {'DataPoint': 10, 'Pregnancies': 8, 'Glucose': 125, 'BloodPressure': 96, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 0, 'DiabetesPedigreeFunction': 0.232, 'Age': 54, 'Outcome': 1},
//   ];
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('ML Model'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             ElevatedButton(
//               onPressed: () {
//                 _showUserInput();
//               },
//               child: Text('User Input'),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () {
//                 _showExistingData();
//               },
//               child: Text('Existing Data'),
//             ),
//             const SizedBox(height: 20),
//             Text('Prediction Result: $predictionResult'),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _showUserInput() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('User Input'),
//           content: SingleChildScrollView(
//             child: Container(
//               width: double.maxFinite,
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   _buildTextField('Pregnancies', pregnanciesController),
//                   _buildTextField('Glucose', glucoseController),
//                   _buildTextField('Blood Pressure', bloodPressureController),
//                   _buildTextField('Skin Thickness', skinThicknessController),
//                   _buildTextField('Insulin', insulinController),
//                   _buildTextField('BMI', bmiController),
//                   _buildTextField('Age', ageController),
//                   const SizedBox(height: 20),
//                   Text('Select ML Model:'),
//                   SizedBox(
//                     height: 100, // Set a fixed height or use Expanded to take remaining space
//                     child: ListView.builder(
//                       itemCount: mlModels.length,
//                       itemBuilder: (context, index) {
//                         return ListTile(
//                           title: Text(mlModels[index]),
//                           onTap: () {
//                             setState(() {
//                               selectedModel = mlModels[index];
//                             });
//                             Navigator.of(context).pop(); // Close the dialog
//                           },
//                         );
//                       },
//                     ),
//                   ),
//                   const SizedBox(height: 20),
//                   ElevatedButton(
//                     onPressed: () {
//                       Navigator.of(context).pop(); // Close the dialog
//                       _makePrediction(_getUserInput());
//                     },
//                     child: Text('Predict'),
//                   ),
//                   const SizedBox(height: 20),
//                   Text(
//                     'Disclaimer: This is a simplified example. Actual ML model integration is more complex.',
//                     style: TextStyle(color: Colors.red),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   void _showExistingData() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Existing Data'),
//           content: Column(
//             children: [
//               MultiSelectFormField(
//                 //autovalidate: false,
//                 title: Text('Select ML Models'),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please select at least one model';
//                   }
//                   return null;
//                 },
//                 dataSource: mlModels
//                     .map((model) => {'display': model, 'value': model})
//                     .toList(),
//                 textField: 'display',
//                 valueField: 'value',
//                 okButtonLabel: 'OK',
//                 cancelButtonLabel: 'CANCEL',
//                 hintWidget: Text('Please choose one or more'),
//                 initialValue: selectedModel,
//                 onSaved: (value) {
//                   if (value == null) return;
//                   setState(() {
//                     selectedModel = value;
//                   });
//                 },
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: () {
//                   _makePrediction(_getSelectedData());
//                 },
//                 child: Text('Predict'),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
//
//   Future<void> _makePrediction(List<Map<String, dynamic>> inputData) async {
//     try {
//       final result = 'hi';
//       print("hi");
//       // // Make a prediction using DartPy
//       // final result = await PythonHelper.makePrediction(inputData);
//       //
//       // // Update the predictionResult state with the received prediction
//       // setState(() {
//          predictionResult = '$result';
//     } catch (e) {
//       print('Error making prediction: $e');
//     }
//   }
//
//   // @override
//   // void dispose() {
//   //   PythonHelper.cleanupPython(); // Cleanup DartPy
//   //   super.dispose();
//   // }
//
//
//   void _showData(String data) {
//     // Implement your logic to show the selected data
//     // For simplicity, we'll just print the selected data
//     print('Selected Data: $data');
//   }
//
//   List<Map<String, dynamic>> _getUserInput() {
//     // Retrieve user input data
//     return [
//       {
//         'Pregnancies': int.parse(pregnanciesController.text),
//         'Glucose': int.parse(glucoseController.text),
//         'BloodPressure': int.parse(bloodPressureController.text),
//         'SkinThickness': int.parse(skinThicknessController.text),
//         'Insulin': int.parse(insulinController.text),
//         'BMI': double.parse(bmiController.text),
//         'Age': int.parse(ageController.text),
//       }
//     ];
//   }
//
//   List<Map<String, dynamic>> _getSelectedData() {
//     // Retrieve selected data from the existing dataset
//     final int selectedIndex = int.parse(selectedData) - 1;
//     return [data[selectedIndex]];
//   }
//
//   Widget _buildTextField(String label, TextEditingController controller) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: TextField(
//         controller: controller,
//         decoration: InputDecoration(labelText: label),
//         keyboardType: TextInputType.number,
//       ),
//     );
//   }
// }
//
// extension ListExtensions<T> on List<T> {
//   // Shuffle the list
//   List<T> get shuffled {
//     final List<T> list = List<T>.from(this);
//     for (int i = list.length - 1; i > 0; i--) {
//       final int n = (i * 0.5).floor();
//       final T temp = list[i];
//       list[i] = list[n];
//       list[n] = temp;
//     }
//     return list;
//   }
// }
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MLModel()),
                );
              },
              child: Text('User Input'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DatasetInputPage()),
                );
              },
              child: Text('Dataset Input'),
            ),
          ],
        ),
      ),
    );
  }
}

class DatasetInputPage extends StatefulWidget {
  @override
  _DatasetInputPageState createState() => _DatasetInputPageState();
}
class _DatasetInputPageState extends State<DatasetInputPage> {
  String selectedDataset = 'Dataset 1'; // Default selected dataset

  List<String> datasetOptions = [
    'Dataset 1',
    'Dataset 2',
    'Dataset 3',
    'Dataset 4',
    'Dataset 5',
    'Dataset 6',
    'Dataset 7',
    'Dataset 8',
    'Dataset 9',
    'Dataset 10'
  ];

  List<Map<String, dynamic>> datasets = [
    {'DataPoint': 1, 'Pregnancies': 6, 'Glucose': 148, 'BloodPressure': 72, 'SkinThickness': 35, 'Insulin': 0, 'BMI': 33.6, 'DiabetesPedigreeFunction': 0.627, 'Age': 50, 'Outcome': 1},
    {'DataPoint': 2, 'Pregnancies': 1, 'Glucose': 85, 'BloodPressure': 66, 'SkinThickness': 29, 'Insulin': 0, 'BMI': 26.6, 'DiabetesPedigreeFunction': 0.351, 'Age': 31, 'Outcome': 0},
    {'DataPoint': 3, 'Pregnancies': 8, 'Glucose': 183, 'BloodPressure': 64, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 23.3, 'DiabetesPedigreeFunction': 0.672, 'Age': 32, 'Outcome': 1},
    {'DataPoint': 4, 'Pregnancies': 1, 'Glucose': 89, 'BloodPressure': 66, 'SkinThickness': 23, 'Insulin': 94, 'BMI': 28.1, 'DiabetesPedigreeFunction': 0.167, 'Age': 21, 'Outcome': 0},
    {'DataPoint': 5, 'Pregnancies': 0, 'Glucose': 137, 'BloodPressure': 40, 'SkinThickness': 35, 'Insulin': 168, 'BMI': 43.1, 'DiabetesPedigreeFunction': 2.288, 'Age': 33, 'Outcome': 1},
    {'DataPoint': 6, 'Pregnancies': 5, 'Glucose': 116, 'BloodPressure': 74, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 25.6, 'DiabetesPedigreeFunction': 0.201, 'Age': 30, 'Outcome': 0},
    {'DataPoint': 7, 'Pregnancies': 3, 'Glucose': 78, 'BloodPressure': 50, 'SkinThickness': 32, 'Insulin': 88, 'BMI': 31, 'DiabetesPedigreeFunction': 0.248, 'Age': 26, 'Outcome': 1},
    {'DataPoint': 8, 'Pregnancies': 10, 'Glucose': 115, 'BloodPressure': 0, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 35.3, 'DiabetesPedigreeFunction': 0.134, 'Age': 29, 'Outcome': 0},
    {'DataPoint': 9, 'Pregnancies': 2, 'Glucose': 197, 'BloodPressure': 70, 'SkinThickness': 45, 'Insulin': 543, 'BMI': 30.5, 'DiabetesPedigreeFunction': 0.158, 'Age': 53, 'Outcome': 1},
    {'DataPoint': 10, 'Pregnancies': 8, 'Glucose': 125, 'BloodPressure': 96, 'SkinThickness': 0, 'Insulin': 0, 'BMI': 0, 'DiabetesPedigreeFunction': 0.232, 'Age': 54, 'Outcome': 1},
  ];

  String selectedModel = 'Decision Tree'; // Default selected model

  List<String> models = [
    'Random Forest',
    'Decision Tree',
    'SVM',
    'XGBoost',
    'Gradient Boosting',
  ];
  TextEditingController pregnanciesController = TextEditingController();
  TextEditingController glucoseController = TextEditingController();
  TextEditingController bloodPressureController = TextEditingController();
  TextEditingController skinThicknessController = TextEditingController();
  TextEditingController insulinController = TextEditingController();
  TextEditingController bmiController = TextEditingController();
  TextEditingController diabetesPedigreeFunctionController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController outcomeController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Set initial values for controllers based on the selected dataset
    setControllersValues();
  }

  void setControllersValues() {
    // Find the selected dataset based on the chosen option
    Map<String, dynamic> selectedData = datasets[datasetOptions.indexOf(selectedDataset)];
  print(selectedData);
    // Update controllers with values from the selected dataset
    if (selectedData != null) {
      pregnanciesController.text = selectedData['Pregnancies'].toString();
      glucoseController.text = selectedData['Glucose'].toString();
      bloodPressureController.text = selectedData['BloodPressure'].toString();
      skinThicknessController.text = selectedData['SkinThickness'].toString();
      insulinController.text = selectedData['Insulin'].toString();
      bmiController.text = selectedData['BMI'].toString();
      diabetesPedigreeFunctionController.text = selectedData['DiabetesPedigreeFunction'].toString();
      ageController.text = selectedData['Age'].toString();
      outcomeController.text = selectedData['Outcome'].toString();
    }
    if (outcomeController.text == '1'){
      outcomeController.text = "High Risk";
    }
    else{
      outcomeController.text = "Low Risk";
    }
  }
  @override
  Widget build(BuildContext context) {
    // You can load and display the existing dataset here
    return Scaffold(
      appBar: AppBar(
        title: Text('Dataset Input Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            DropdownButton<String>(
              value: selectedModel,
              onChanged: (String? newValue) {
                setState(() {
                  selectedModel = newValue!;
                });
              },
              items: models.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate to the ML model page based on the selected model
              },
              child: Text('Select Model'),
            ),
            DropdownButton<String>(
              value: selectedDataset,
              onChanged: (String? newValue) {
                setState(() {
                  selectedDataset = newValue!;
                  setControllersValues();
                });
              },
              items: datasetOptions.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: () async {
            await showPredictionResultDialog(outcomeController.text);
          },
          child: Text('Make Prediction'),
        ),
            ElevatedButton(
              onPressed: () {
                // Process the selected dataset based on the user's choice
                // For demonstration, printing the selected datase
              },
              child: Text('Process Dataset'),
            ),
          ],
        ),
      ),
    );
  }
  Future<void> showPredictionResultDialog(
      String predictionResult) async {
    showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Prediction Result'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Your prediction result is:'),
                Text('$predictionResult',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text("Ground Truth : $predictionResult"),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class MLModel extends StatefulWidget {
  @override
  _MLModelState createState() => _MLModelState();
}

class _MLModelState extends State<MLModel> {
  String predictionResult = '';
  final _formKey = GlobalKey<FormState>();
  final pregnanciesController = TextEditingController();
  final glucoseController = TextEditingController();
  final bloodPressureController = TextEditingController();
  final skinThicknessController = TextEditingController();
  final insulinController = TextEditingController();
  final bmiController = TextEditingController();
  final sdController = TextEditingController();
  final ageController = TextEditingController();
  // Future<void> _makePrediction(List<Map<String, dynamic>> inputData) async {
  Future<void> _makePrediction() async {
    try {
      // Validate the form
      if (_formKey.currentState!.validate()) {
        // Retrieve user input data
        Map<String, dynamic> inputData = {
          'Pregnancies': int.parse(pregnanciesController.text),
          'Glucose': int.parse(glucoseController.text),
          'BloodPressure': int.parse(bloodPressureController.text),
          'SkinThickness': int.parse(skinThicknessController.text),
          'Insulin': int.parse(insulinController.text),
          'BMI': double.parse(bmiController.text),
          "DiabetesPedigreeFunction" : double.parse(sdController.text),
          'Age': int.parse(ageController.text),
        };
        }
    Map<String, dynamic> inputData = {
      'Pregnancies': pregnanciesController.text,
      'Glucose': glucoseController.text,
      'BloodPressure': bloodPressureController.text,
      'SkinThickness': skinThicknessController.text,
      'Insulin': insulinController.text,
      'BMI': bmiController.text,
      'DiabetesPedigreeFunction': sdController.text,
      'Age': ageController.text,
    };
      print(jsonEncode(inputData));
      final response = await http.post(
        Uri.parse('http://192.168.29.50:5000/a'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(inputData),
      );
      Map<String, dynamic> result = jsonDecode(response.body);
      //print("Hello");
      //print(result['prediction']);
      if (response.statusCode == 200) {
        print("Hello");
        print(result['prediction']);
        //print(result['prediction'].join());
        String final1 = result['prediction'].join();
        if (final1 == '1'){
          print("yes");
          predictionResult = 'High Risk';
          showPredictionResultDialog(context, predictionResult);
          print(predictionResult);}
        else{
          predictionResult = 'Low Risk';
          showPredictionResultDialog(context, predictionResult);
        }
      } else {
        throw Exception('Failed to make prediction');
      }
    } catch (e) {
      print('Error making prediction: $e');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ML Model'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Create a text field for each controller
              TextFormField(
                controller: pregnanciesController,
                decoration: InputDecoration(
                  labelText: 'Pregnancies',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: glucoseController,
                decoration: InputDecoration(
                  labelText: 'Glucose (mg/dL)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: bloodPressureController,
                decoration: InputDecoration(
                  labelText: 'Blood Pressure (mm of Hg)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: skinThicknessController,
                decoration: InputDecoration(
                  labelText: 'Skin Thickness (mm)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: insulinController,
                decoration: InputDecoration(
                  labelText: 'Insulin (µU/ml)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: bmiController,
                decoration: InputDecoration(
                  labelText: 'BMI (Kg/m^2)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: sdController,
                decoration: InputDecoration(
                  labelText: 'Diabetes Pedigree Function',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              TextFormField(
                controller: ageController,
                decoration: InputDecoration(
                  labelText: 'Age',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty || double.tryParse(value) == null ) {
                    return 'Please enter a valid input';
                  }
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _makePrediction,
                child: Text('Make Prediction'),
              ),
              // Display the prediction result
              Text(predictionResult),
            ],
          ),
        ),
      ),
    );
  }
}
  void showPredictionResultDialog(BuildContext context,
      String predictionResult) {
    showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Prediction Result'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Your prediction result is:'),
                Text('$predictionResult',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
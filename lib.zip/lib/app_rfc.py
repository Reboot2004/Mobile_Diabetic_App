import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from flask import Flask, request, jsonify
import pickle
import warnings
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

warnings.filterwarnings('ignore')

# Load the diabetes dataset
diabetes_df = pd.read_csv('diabetes.csv')

# Data preprocessing
diabetes_df_copy = diabetes_df.copy(deep=True)
diabetes_df_copy[['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']] = diabetes_df_copy[
    ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']].replace(0, np.NaN)

# Impute missing values
diabetes_df_copy['Glucose'].fillna(diabetes_df_copy['Glucose'].mean(), inplace=True)
diabetes_df_copy['BloodPressure'].fillna(diabetes_df_copy['BloodPressure'].mean(), inplace=True)
diabetes_df_copy['SkinThickness'].fillna(diabetes_df_copy['SkinThickness'].median(), inplace=True)
diabetes_df_copy['Insulin'].fillna(diabetes_df_copy['Insulin'].median(), inplace=True)
diabetes_df_copy['BMI'].fillna(diabetes_df_copy['BMI'].median(), inplace=True)

# Standardize the features
sc_X = StandardScaler()
X = pd.DataFrame(sc_X.fit_transform(diabetes_df_copy.drop(["Outcome"], axis=1)),
                 columns=['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI',
                          'DiabetesPedigreeFunction', 'Age'])

# Split the data into features (X) and target variable (y)
y = diabetes_df['Outcome']
import xgboost as xgb
# Train the RandomForestClassifier
model = xgb.XGBClassifier()
model.fit(X, y)

# Save the model to a file
filename = 'xgb_model.pkl'
pickle.dump(model, open(filename, 'wb'))

# Function to make predictions
def predict(data):
    try:
        loaded_model = pickle.load(open('random_forest_model.pkl', 'rb'))
        # Ensure the input data has the same columns as the training data
        input_df = pd.DataFrame([data], columns=['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI',
                                                 'DiabetesPedigreeFunction', 'Age'])

        # Standardize the input data
        input_data = sc_X.transform(input_df)

        # Make predictions using the loaded model
        predictions = loaded_model.predict(input_data)
        print(predictions)
        return predictions.tolist()
    except Exception as e:
        return {'error': str(e)}

@app.route('/a', methods=['GET','POST'])
def make_prediction():
    try:
        data = request.get_json(force=True)
        #data1 = json.loads(data)
        print(data)
        prediction = predict(data)
        print(prediction)
        return jsonify({'prediction': prediction})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

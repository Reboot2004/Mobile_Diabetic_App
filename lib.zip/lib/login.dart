import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'h.dart';
import 'register.dart';

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<Login> {
  TextEditingController usernameC = TextEditingController();
  TextEditingController passwordC = TextEditingController();
  String loggedInUser = ''; // Variable to store the logged-in user

  Future<void> _signIn() async {
    String username = usernameC.text.trim();
    String password = passwordC.text.trim();

    if (username.isEmpty || password.isEmpty) {
      // Show an alert for empty fields
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Sign In Failed'),
            content: const Text('Please enter both username and password.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
      return;
    }

    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('username', isEqualTo: username)
        .where('password', isEqualTo: password)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      // Set the logged-in user
      setState(() {
        loggedInUser = username;
      });

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Sign In Successful'),
            content: const Text('You have successfully signed in.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            WelcomeScreen(username: loggedInUser)),
                            //DataViewerWithUsername(username: loggedInUser)),
                  );
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Sign In Failed'),
            content: const Text('Invalid username or password. Please try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile Diabetic App'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(0, 40, 0, 60),
              child: Text('Login',
                  style:
                  TextStyle(fontSize: 37.5, fontWeight: FontWeight.bold)),
            ),
            const Text('Username', style: TextStyle(fontSize: 18)),
            Padding(
              padding: const EdgeInsets.all(20),
              child: TextField(
                controller: usernameC,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter your username'),
              ),
            ),
            const Text('Password', style: TextStyle(fontSize: 18)),
            Padding(
              padding: const EdgeInsets.all(20),
              child: TextField(
                controller: passwordC,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter your password'),
                obscureText: true,
              ),
            ),
            TextButton(
              onPressed: _signIn,
              style: ButtonStyle(
                backgroundColor:
                MaterialStateProperty.all<Color>(Colors.blue),
                foregroundColor:
                MaterialStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('Login'),
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor:
                MaterialStateProperty.all<Color>(Colors.blue),
                foregroundColor:
                MaterialStateProperty.all<Color>(Colors.white),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Register()),
                );
              },
              child: const Text('Sign Up'),
            ),
            TextButton(
              style: ButtonStyle(
                foregroundColor:
                MaterialStateProperty.all<Color>(Colors.blue),
              ),
              onPressed: () {
                // Add forgot password functionality
              },
              child: const Text('Forgot password?'),
            ),
          ],
        ),
      ),
    );
  }
}
class VerificationResult {
  final String? verificationSid;
  final int statusCode;
  VerificationResult({required this.verificationSid, required this.statusCode});
}

import 'package:email_otp/email_otp.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:twilio_flutter/twilio_flutter.dart';
import 'login.dart';
import 'register.dart';
import 'dialog.dart';
import 'email.dart';
//import 'py.dart';
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
void main() async {
  //await Firebase.initializeApp();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  //PythonHelper.initializePython(); // Initialize DartPy
  //await PythonFfi.instance.initialize();
  runApp(const MyApp());
}
final CollectionReference users = FirebaseFirestore.instance.collection('users');
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Login(),
    );
  }
}
//
//
// class OtpInput extends StatelessWidget {
//   final TextEditingController otpController;
//   final VoidCallback onVerifyPressed;
//   const OtpInput({
//     Key? key,
//     required this.otpController,
//     required this.onVerifyPressed,
//   }) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         const Text('OTP', style: TextStyle(fontSize: 18)),
//         Padding(
//           padding: const EdgeInsets.all(20),
//           child: SizedBox(
//             width: 250,
//             child: TextField(
//               controller: otpController,
//               decoration: const InputDecoration(
//                 border: OutlineInputBorder(),
//                 hintText: 'Enter OTP',
//               ),
//             ),
//           ),
//         ),
//         TextButton(
//           onPressed: onVerifyPressed,
//           style: ButtonStyle(
//             foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
//           ),
//           child: const Text('Verify OTP'),
//         ),
//       ],
//     );
//   }
// }
// import 'home.dart';
// import 'predict.dart';
// import 'dialog.dart';
// import 'package:email_otp/email_otp.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:twilio_flutter/twilio_flutter.dart';
// final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(const MyApp());
// }
// final CollectionReference users = FirebaseFirestore.instance.collection('users');
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//   @override
//   Widget build(BuildContext context) {
//     return const MaterialApp(
//       home: Login(),
//     );
//   }
// }
// class Login extends StatefulWidget {
//   const Login({super.key});
//
//   @override
//   _LoginPageState createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<Login> {
//   TextEditingController usernameC = TextEditingController();
//   TextEditingController passwordC = TextEditingController();
//   String? loggedInUsername;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Mobile Diabetic App'),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         child: loggedInUsername == null
//             ? buildLoginScreen()
//             : buildWelcomeScreen(),
//       ),
//     );
//   }
//
//   Widget buildLoginScreen() {
//     return Column(
//       children: [
//         const Padding(
//           padding: EdgeInsets.fromLTRB(0, 40, 0, 60),
//           child: Text('Login', style: TextStyle(fontSize: 37.5, fontWeight: FontWeight.bold)),
//         ),
//         const Text('Username', style: TextStyle(fontSize: 18)),
//         Padding(
//           padding: const EdgeInsets.all(20),
//           child: TextField(
//             controller: usernameC,
//             decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Enter your username'),
//           ),
//         ),
//         const Text('Password', style: TextStyle(fontSize: 18)),
//         Padding(
//           padding: const EdgeInsets.all(20),
//           child: TextField(
//             controller: passwordC,
//             decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Enter your password'),
//             obscureText: true,
//           ),
//         ),
//         TextButton(
//           onPressed: () async {
//             String username = usernameC.text;
//             String password = passwordC.text;
//             QuerySnapshot querySnapshot = await FirebaseFirestore.instance
//                 .collection('users')
//                 .where('username', isEqualTo: username)
//                 .where('password', isEqualTo: password)
//                 .get();
//             if (querySnapshot.docs.isNotEmpty) {
//               setState(() {
//                 loggedInUsername = username;
//               });
//               showDialog(
//                 context: context,
//                 builder: (BuildContext context) {
//                   return AlertDialog(
//                     title: const Text('Sign In Successful'),
//                     content: const Text('You have successfully signed in.'),
//                     actions: <Widget>[
//                       TextButton(
//                         onPressed: () {
//                           Navigator.of(context).pop();
//                           // You can navigate to another screen here
//                         },
//                         child: const Text('OK'),
//                       ),
//                     ],
//                   );
//                 },
//               );
//             } else {
//               showDialog(
//                 context: context,
//                 builder: (BuildContext context) {
//                   return AlertDialog(
//                     title: const Text('Sign In Failed'),
//                     content: const Text('Invalid username or password. Please try again.'),
//                     actions: <Widget>[
//                       TextButton(
//                         onPressed: () {
//                           Navigator.of(context).pop();
//                         },
//                         child: const Text('OK'),
//                       ),
//                     ],
//                   );
//                 },
//               );
//             }
//           },
//           style: ButtonStyle(
//             backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
//             foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
//           ),
//           child: const Text('Login'),
//         ),
//         TextButton(
//           style: ButtonStyle(
//             backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
//             foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
//           ),
//           onPressed: () {
//             Navigator.push(
//               context,
//               MaterialPageRoute(builder: (context) => const Register()),
//             );
//           },
//           child: const Text('Sign Up'),
//         ),
//         // TextButton(
//         //   style: ButtonStyle(
//         //     foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
//         //   ),
//         //   onPressed: () {},
//         //   child: const Text('forgot password?'),
//         // ),
//       ],
//     );
//   }
//
//   Widget buildWelcomeScreen() {
//     return Column(
//       children: [
//         const Padding(
//           padding: EdgeInsets.fromLTRB(200,40,50,0),
//           child: Text('Welcome', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
//         ),
//         const SizedBox(height: 20),
//         Text('Welcome $loggedInUsername!'),
//         const SizedBox(height: 20),
//         ElevatedButton(
//           onPressed: () {
//             // Navigate to the data viewer screen
//             Navigator.push(
//               context,
//               MaterialPageRoute(builder: (context) => DataViewerWithUsername(username: loggedInUsername)),
//             );
//           },
//           child: const Text('View Data'),
//         ),
//         const SizedBox(height: 20),
//         ElevatedButton(
//           onPressed: () {
//             setState(() {
//               loggedInUsername = null;
//             });
//           },
//           child: const Text('Logout'),
//         ),
//       ],
//     );
//   }
// }
// class VerificationResult {
//   final String? verificationSid;
//   final int statusCode;
//   VerificationResult({required this.verificationSid, required this.statusCode});
// }
//
//
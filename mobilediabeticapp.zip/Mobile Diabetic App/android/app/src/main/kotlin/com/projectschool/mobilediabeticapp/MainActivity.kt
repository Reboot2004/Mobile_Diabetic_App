package com.projectschool.mobilediabeticapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

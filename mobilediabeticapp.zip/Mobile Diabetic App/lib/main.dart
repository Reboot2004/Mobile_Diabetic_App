// import 'package:flutter/material.dart';
//
// void main() => runApp(MaterialApp(
//   home: Login()
// ));
//
// class Login extends StatelessWidget {
//   const Login({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return  Scaffold(
//       appBar: AppBar(
//         title: Text('Mobile Diabetic App'),
//         centerTitle: true,
//       ),
//       body: Column(
//         children:[
//           Padding(
//             padding: EdgeInsets.all(80),
//             child: Text('Login',style:TextStyle(fontSize: 37.5,fontWeight: FontWeight.bold)),
//           ),
//           Text('Username',style:TextStyle(fontSize:18)),
//           Padding(
//             padding: EdgeInsets.all(20),
//             child: TextField(controller: _controller,decoration: InputDecoration(border: OutlineInputBorder(),hintText: 'Enter your username'),),
//           ),
//           Text('Password',style:TextStyle(fontSize:18)),
//           Padding(
//             padding: EdgeInsets.all(20),
//             child: TextField(decoration: InputDecoration(border: OutlineInputBorder(),hintText: 'Enter your password'),),
//           ),
//           TextButton(style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),onPressed: () { },child: Text('Login'),),
//           TextButton(style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),onPressed: () { },child: Text('Sign Up'),),
//           TextButton(style: ButtonStyle(foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),),onPressed: () { },child: Text('forgot password?'),)
//
//         ]
//       )
//     );
//
//
//   }
// }
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:email_auth/email_auth.dart';
import 'package:twilio_flutter/twilio_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

final CollectionReference users = FirebaseFirestore.instance.collection('users');

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Login(),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<Login> {
  TextEditingController usernameC = TextEditingController();
  TextEditingController passwordC = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(
          title: const Text('Mobile Diabetic App'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
              children:[
                const Padding(
                  padding: EdgeInsets.fromLTRB(0,40,0,60),
                  child: Text('Login',style:TextStyle(fontSize: 37.5,fontWeight: FontWeight.bold)),
                ),
                const Text('Username',style:TextStyle(fontSize:18)),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextField(controller: usernameC,decoration: const InputDecoration(border: OutlineInputBorder(),hintText: 'Enter your username'),),
                ),
                const Text('Password',style:TextStyle(fontSize:18)),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextField(controller: passwordC,decoration: const InputDecoration(border: OutlineInputBorder(),hintText: 'Enter your password'),obscureText: true,),
                ),
                TextButton(
                  onPressed: () async {
                    String username = usernameC.text;
                    String password = passwordC.text;

                    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('users').where('username', isEqualTo: username).where('password', isEqualTo: password).get();

                    if (querySnapshot.docs.isNotEmpty) {
                      // User found in Firestore, show success dialog
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text('Sign In Successful'),
                            content: const Text('You have successfully signed in.'),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                  // You can navigate to another screen here
                                },
                                child: const Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    } else {
                      // User not found in Firestore, show error dialog
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text('Sign In Failed'),
                            content: const Text('Invalid username or password. Please try again.'),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: const Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    }
                  },style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),child: const Text('Login'),),
                TextButton(style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Register()),
                  );
                },child: const Text('Sign Up'),),
                TextButton(style: ButtonStyle(foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),),onPressed: () { },child: const Text('forgot password?'),)

              ]
          ),
        )
    );
  }
}
class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final CollectionReference usersCollection = FirebaseFirestore.instance.collection('users');

  TextEditingController usernameC = TextEditingController();
  TextEditingController emailC = TextEditingController();
  TextEditingController passwordC = TextEditingController();
  TextEditingController confirmPasswordC = TextEditingController();
  TextEditingController otpC = TextEditingController();
  TextEditingController phoneNumberC = TextEditingController();



  // void verifyOTP() {
  //   EmailAuth emailAuth = EmailAuth(sessionName: "Session");
  //   var response = emailAuth.validateOtp(recipientMail: emailC.text, userOtp: otpC.text );
  // }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(
          title: const Text('Mobile Diabetic App'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                  children:[
                    const Padding(
                      padding: EdgeInsets.fromLTRB(0,40,0,60),
                      child: Text('Sign Up',style:TextStyle(fontSize: 37.5,fontWeight: FontWeight.bold)),
                    ),
                    const Text('Username',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: usernameC, decoration: const InputDecoration(labelText: 'Username',), validator: (value) {
                        if (value!.isEmpty) {
                          return 'Username is required';
                        }
                        return null;
                      },
                      ),
                    ),
                    const Text('Phone Number',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: phoneNumberC, decoration: const InputDecoration(labelText: 'Phone Number',), validator: (value) {
                        if (value!.isEmpty) {
                          return 'Phone Number is required';
                        }
                        return null;
                      },
                      ),
                    ),
                    const Text('E-mail',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: emailC, decoration: const InputDecoration(labelText: 'Email',),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Email is required';
                          }
                          if (!value.contains('@')) {
                            return 'Enter a valid email address';
                          }
                          return null;
                        },
                      ),
                    ),
                    const Text('Password',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: passwordC, decoration: const InputDecoration(labelText: 'Password',), obscureText: true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Password is required';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters';
                          }
                          return null;
                        },
                      ),
                    ),
                    const Text('Confirm Password',style:TextStyle(fontSize:18)),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(controller: confirmPasswordC, decoration: const InputDecoration(labelText: 'Confirm Password',), obscureText: true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please confirm your password';
                          }
                          if (value != passwordC.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                    ),

                    TextButton(style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),foregroundColor: MaterialStateProperty.all<Color>(Colors.white),),onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => PhoneVerification(phoneNumberC: phoneNumberC,),)
                      );
                    },child: const Text('Verify'),),
                  ]
              ),

            )
        )
    );
  }
  Future<void> registerUser(String email, String password, String username) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Add user data to Firestore
      await usersCollection.add({
        'username': username,
        'email': email,
        'uid': userCredential.user?.uid,
        'password' : password
      });

      // Registration successful
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Registration Successful'),
            content: const Text('You can now sign in with your credentials.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                  // Navigate to the login page or any other screen.
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      print("Error during registration: $e");
      // Handle the registration error, e.g., display an error message.
    }
  }
}


class PhoneVerification extends StatefulWidget {
  final TextEditingController phoneNumberC;

  const PhoneVerification({super.key, required this.phoneNumberC});

  @override
  State<PhoneVerification> createState() => _PhoneVerificationState(phoneNumberC: phoneNumberC);
}

class _PhoneVerificationState extends State<PhoneVerification> {
  final TextEditingController phoneNumberC;

  _PhoneVerificationState({required this.phoneNumberC});
  TextEditingController otpC = TextEditingController();

  final TwilioFlutter twilioFlutter = TwilioFlutter(
    accountSid: 'AC01c9b0402b8303c530a9527b5f0e40b7',
    authToken: '1c1e2e8e0248fec0f0a0ea7e334ddef1',
    twilioNumber: 'phoneNumberC',
  );

  void sendOTP() async {
    String phoneNumber = phoneNumberC.text;

    // Generate a random 6-digit OTP
    String otp = _generateOTP();

    // Send OTP using Twilio
    try {
      await twilioFlutter.sendSMS(
        toNumber: phoneNumber,
        messageBody: 'Your verification code is $otp',
      );

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('OTP Sent'),
            content: const Text('An OTP has been sent to your phone number.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      // Handle error when OTP cannot be sent
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text('Failed to send OTP. Please try again.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }


  String _generateOTP() {
    // Generate a random 6-digit OTP
    return ((100000 + (DateTime.now().millisecondsSinceEpoch % 900000)).toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile Diabetic App'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(0, 40, 0, 60),
              child: Text('Phone Verification', style: TextStyle(fontSize: 37.5, fontWeight: FontWeight.bold)),
            ),
            const Text('Phone Number', style: TextStyle(fontSize: 18)),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: SizedBox(
                    width: 250,
                    child: TextField(controller: phoneNumberC, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Enter your phone number'),),
                  ),
                ),
                TextButton(
                  onPressed: () => sendOTP(),
                  style: ButtonStyle(
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  ),
                  child: const Text('Send OTP'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


/*
class email extends StatefulWidget {
  final TextEditingController emailC;

  email({required this.emailC});

  @override
  State<email> createState() => _emailState(emailC: emailC);
}


class _emailState extends State<email> {
  final TextEditingController emailC;

  _emailState({required this.emailC});
  TextEditingController otpC = TextEditingController();
  var remoteServerConfiguration = {'host':'smtp.gmail.com','port':'587','username':'','password':''};


  void sendOTP() async {
    EmailAuth emailAuth = EmailAuth(sessionName: "Session");
    emailAuth.sessionName = "Session";
    emailAuth.config(remoteServerConfig);
    var response = await emailAuth.sendOtp(recipientMail: emailC.text);
    if (response){
      showDialog(context: context, builder: (BuildContext context){
        return AlertDialog(
          title: Text('OTP Sent'),
          content: Text('An OTP has been sent to your email address.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                // Navigate to the login page or any other screen.
              },
              child: Text('OK'),
            ),
          ],
        );
      });

    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile Diabetic App'),
      ),
      body: SingleChildScrollView(
        child:Column(
            children:[const Padding(
              padding: EdgeInsets.fromLTRB(0,40,0,60),
              child: Text('Verification',style:TextStyle(fontSize: 37.5,fontWeight: FontWeight.bold)),
            ),
            const Text('OTP',style:TextStyle(fontSize:18)),
            Row(
              children:[Padding(
                  padding: const EdgeInsets.all(20),
                  child: SizedBox(width:250,
                    child:TextField(controller: otpC,decoration: const InputDecoration(border: OutlineInputBorder(),hintText: 'Enter the OTP'),),
                  )
              ),
              TextButton(onPressed: () => sendOTP(),style: ButtonStyle(foregroundColor: MaterialStateProperty.all<Color>(Colors.blue),),child: Text('Send OTP'),)]
            ),


        ])
      )
        );
    }
}
*/